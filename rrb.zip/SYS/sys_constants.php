<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

$C_COPYRIGHT_TEXT ="&nbsp;&nbsp;&nbsp;Shavrak & Kotlayr &copy; 2012";
$C_PROJECT_NAME ="Russian Real Estate Base";
?>
